Two versions of this database available.

1) Preprocessed data can be found in optdigits.tra and optdigits.tes
   See optdigits.names for information regarding the preprocessing.

2) The original format of the data can be found in files prefixed with
   optdigits-orig.

Cathy Blake
Sept 3,1998 
